<div>
    <div class="container">
        <div class="col-md-12 text-end">
            <input type="search" wire:model="search" class="form-control float-end mx-2" placeholder="Buscar..."
                style="width: 230px" />
        </div>
        <div class="col-md-12"><h4>Incidentes</h4></div>
        <div class="col-md-12">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Accion</th>
                        <th>Fecha</th>
                        <th>Boleta</th>
                        <th>Numero de Serie</th>
                    </tr>
                </thead>
                </thead>
                <tbody>
                    @forelse ($incidents as $incident)
                    <tr>
                        <td>{{ $incident->tarea }}</td>
                        <td>{{ $incident->fecha }}</td>
                        <td>{{ $incident->boleta }}</td>
                        <td>{{ $incident->nroserie }}</td>
                    </tr>
                    @empty
                        <tr>
                            <td colspan="4">No se encontraron resultados</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
            <div>
                {{ $incidents->links() }}
            </div>
        </div>
        <div class="col-md-12"><h4>Servicios</h4></div>
        <div class="col-md-12">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Direccion</th>
                        <th>Fecha Ingreso</th>
                        <th>Nro Cliente</th>
                        <th>Numero de Serie</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($services as $service)
                    <tr>
                        <td>{{ $service->direccion }}</td>
                        <td>{{ $service->ingreso }}</td>
                        <td>{{ $service->nrocliente }}</td>
                        <td>{{ $service->nroserie }}</td>
                    </tr>
                    @empty
                        <tr>
                            <td colspan="4">No se encontraron resultados</td>
                        </tr>
                    @endforelse

                </tbody>
            </table>
            <div>
                {{ $services->links() }}
            </div>
        </div>

    </div>
</div>
