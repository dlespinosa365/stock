<?php

namespace App\Http\Livewire;
use App\Models\HistoricalIncident;
use App\Models\HistoricalService;

class HistoricalIncidentComponent extends CustomMasterComponent
{
    public $search = '';

    public function render()
    {
        $incidents = HistoricalIncident::where('nroserie', 'like', '%' . $this->search . '%')
                    ->orderBy('id', 'DESC')
                    ->paginate(10, ['*'], 'incidentsPage');
        $services = HistoricalService::where('nroserie', 'like', '%' . $this->search . '%')
                    ->orderBy('nroserv', 'DESC')
                    ->paginate(10, ['*'], 'servicesPage');

        return view('livewire.historical-incident-list', [
               'incidents' => $incidents,
               'services' => $services
            ])
            ->layout('layouts.app',
                [
                    'header' => 'Listado de Movimientos Historico'
                ]
            );
    }
}
