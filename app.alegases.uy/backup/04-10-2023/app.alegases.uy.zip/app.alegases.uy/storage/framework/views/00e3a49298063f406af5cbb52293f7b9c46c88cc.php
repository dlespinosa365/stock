<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'btn btn-outline-secondary text-uppercase'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /home/denis/stock/alegas/resources/views/vendor/jetstream/components/secondary-button.blade.php ENDPATH**/ ?>