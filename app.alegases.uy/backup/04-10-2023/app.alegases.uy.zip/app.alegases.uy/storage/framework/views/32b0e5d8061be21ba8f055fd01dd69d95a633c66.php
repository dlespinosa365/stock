<div>
    <?php echo $__env->make('livewire.product-type-forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="col-md-12 text-end">
            <input type="search" wire:model="search" class="form-control float-end mx-2" placeholder="Buscar..."
                style="width: 230px" />
            <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                data-bs-target="#createProductType">Nuevo</button>
        </div>
        <?php if(session()->has('message')): ?>
            <br>
            <div class="col-md-12">
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('message')); ?>

                </div>
            </div>
        <?php endif; ?>
        <div class="col-md-12">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $productTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($productType->id); ?></td>
                            <td><?php echo e($productType->name); ?></td>
                            <td>
                                <button type="button"
                                    data-bs-toggle="modal"
                                    data-bs-target="#updateProductType"
                                    class="btn btn-outline-primary"
                                    wire:click="edit(<?php echo e($productType->id); ?>)">Editar</button>
                                <button type="button"
                                    data-bs-toggle="modal"
                                    data-bs-target="#deleteProductType"
                                    class="btn btn-outline-danger"
                                    wire:click="delete(<?php echo e($productType->id); ?>)">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3">No se encontraron resultados</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <div>
                <?php echo e($productTypes->links()); ?>

            </div>
        </div>

    </div>
</div>
<?php /**PATH /home/alegas5/app.alegases.uy/resources/views/livewire/product-type-list.blade.php ENDPATH**/ ?>