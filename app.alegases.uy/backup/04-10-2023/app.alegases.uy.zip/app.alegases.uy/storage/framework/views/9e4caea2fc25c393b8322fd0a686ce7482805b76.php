<div>
    <div class="container">
        <div class="col-md-12 text-end">
            <input type="search" wire:model="search" class="form-control float-end mx-2" placeholder="Buscar..."
                style="width: 230px" />
        </div>
        <div class="col-md-12"><h4>Incidentes</h4></div>
        <div class="col-md-12">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Accion</th>
                        <th>Fecha</th>
                        <th>Boleta</th>
                        <th>Numero de Serie</th>
                    </tr>
                </thead>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $incidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incident): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($incident->tarea); ?></td>
                        <td><?php echo e($incident->fecha); ?></td>
                        <td><?php echo e($incident->boleta); ?></td>
                        <td><?php echo e($incident->nroserie); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">No se encontraron resultados</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <div>
                <?php echo e($incidents->links()); ?>

            </div>
        </div>
        <div class="col-md-12"><h4>Servicios</h4></div>
        <div class="col-md-12">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Direccion</th>
                        <th>Fecha Ingreso</th>
                        <th>Nro Cliente</th>
                        <th>Numero de Serie</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($service->direccion); ?></td>
                        <td><?php echo e($service->ingreso); ?></td>
                        <td><?php echo e($service->nrocliente); ?></td>
                        <td><?php echo e($service->nroserie); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">No se encontraron resultados</td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>
            <div>
                <?php echo e($services->links()); ?>

            </div>
        </div>

    </div>
</div>
<?php /**PATH /home/alegas5/app.alegases.uy/resources/views/livewire/historical-incident-list.blade.php ENDPATH**/ ?>