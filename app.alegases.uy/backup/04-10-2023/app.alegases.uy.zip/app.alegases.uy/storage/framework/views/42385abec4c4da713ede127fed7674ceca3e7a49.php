<div wire:ignore.self class="modal fade" id="createMovement" tabindex="-1" role="dialog"
    aria-labelledby="createMovementLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createMovementLabel">Nuevo Movimiento</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close" wire:click="resetAddForm">
                    <span aria-hidden="true close-btn">×</span>
                </button>
            </div>
            <form wire:submit.prevent="store" onkeydown="return event.key != 'Enter';">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="serial_number" class="form-label">Numero(s) de Serie</label>
                        <input type="text" class="form-control" id="serial_number_to_add" placeholder=""
                            wire:model="serial_number_to_add" wire:keydown.enter="addSerialToList">
                        <?php if($show_error_missing_serials): ?>
                            <span class="text-danger">No se ha agregado nigun numero de serie</span>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <?php $__currentLoopData = $serials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong>
                                <span class="badge bg-secondary"
                                    wire:click="removeSerialFromList( <?php echo e($serial); ?> )"><?php echo e($serial); ?></span>
                            </strong>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mb-3">
                        <label for="location_id_to_add" class="form-label">Nueva Ubicacion</label>
                        <select class="form-select" aria-label="Unicacion" wire:model="location_id_to_add">
                            <option value="">BAJA</option>
                            <?php $__currentLoopData = $intern_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($location->id); ?>"><?php echo e($location->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($customer->location->id); ?>">[<?php echo e($customer->external_number); ?>] - <?php echo e($customer->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="date_to_add" class="form-label">Fecha</label>
                        <input type="date" wire:model="date_to_add" class="form-control" id="date_to_add" name="date_to_add">
                    </div>
                    <div class="mb-3">
                        <label for="description_to_add" class="form-label">Descripcion</label>
                        <textarea class="form-control" id="description_to_add" rows="3" wire:model="description_to_add"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-dismiss="modal"
                        wire:click="resetAddForm"> Cancelar</button>
                    <button type="submit" class="btn btn-outline-success">Crear</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /home/alegas5/app.alegases.uy/resources/views/livewire/movement-new-form.blade.php ENDPATH**/ ?>