welcome
<?php /**PATH /home/denis/stock/alegas/resources/views/welcome.blade.php ENDPATH**/ ?>