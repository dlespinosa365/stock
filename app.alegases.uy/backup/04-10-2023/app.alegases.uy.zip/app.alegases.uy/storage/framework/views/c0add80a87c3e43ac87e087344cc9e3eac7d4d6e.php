<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('images/alegas-36x36.png')); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
    <?php echo \Livewire\Livewire::styles(); ?>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
    <style>
        @page {
            margin: 0cm;
        }
    </style>
</head>

<body class="font-sans antialiased bg-light">
    <header>
        <div class="text-center mt-3">
            <h5 class=""><?php echo e($header); ?></h5>
        </div>
    </header>
    <!-- Page Content -->
    <main class="container">
        <?php echo e($slot); ?>

    </main>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function() {
            window.print();
        });
        window.onafterprint = function() {
            window.location = window.location.origin + '/inicio'
        }
    </script>
</body>

</html>
<?php /**PATH /home/denis/stock/alegas/resources/views/layouts/print.blade.php ENDPATH**/ ?>