<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-dark text-uppercase'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /home/alegas5/app.alegases.uy/resources/views/vendor/jetstream/components/button.blade.php ENDPATH**/ ?>