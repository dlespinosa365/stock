<div>
    <div class="container">
        <div class="row mb-4">
            <div class="col-md-12 mb5">
                <h3 class="h3 my-4">Consulta de stock de producto</h3>
            </div>
            <div class="col-md-5">
                <select class="form-select" aria-label="Ubicacion" wire:model="locationId">
                    <option value="" selected>Seleccione una ubicacion</option>
                    <?php $__currentLoopData = $intern_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($location->id); ?>"><?php echo e($location->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($customer->location->id); ?>">[<?php echo e($customer->external_number); ?>] -
                            <?php echo e($customer->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-5">
                <input type="search" wire:model="serialNumber" class="form-control" placeholder="Numero de serie" />
            </div>
            <div class="col-md-2">
                <button type="button" class="btn btn-outline-success" wire:click="print">Imprimir</button>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Tipo</th>
                            <th>Numero de serie</th>
                            <th>Ubicacion</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($product->productType?->name); ?></td>
                                <td><?php echo e($product->serial_number); ?></td>
                                <td><?php echo e($product->currentLocation?->name); ?></td>
                                <td>
                                    <button type="button" data-bs-toggle="modal"
                                        data-bs-target="#showThreeLastMovement" class="btn btn-outline-primary"
                                        wire:click="showThreeLastMovementFn(<?php echo e($product->id); ?>)">
                                        Ultimos movimientos
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4">No se encontraron resultados</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div>
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>
    <div wire:ignore.self class="modal fade" id="showThreeLastMovement" tabindex="-1" role="dialog"
        aria-labelledby="showThreeLastMovementLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="showThreeLastMovementLabel">Ultimos Movimientos del producto
                        <?php echo e($productToFind?->serial_number); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true close-btn" wire:click="closeModalshowThreeLastMovementFn">×</span>
                    </button>
                </div>

                <div class="modal-body">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Origen</th>
                                <th>Destino</th>
                                <th>Tipo</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__empty_1 = true; $__currentLoopData = $lastMovements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($movement->created_at->diffForHumans()); ?></td>
                                    <td><?php echo e($movement->locationFrom?->name); ?></td>
                                    <td><?php echo e($movement->locationTo?->name); ?></td>
                                    <td><?php echo e($movement->movementType?->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4">No se encontraron resultados</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-primary" data-dismiss="modal"
                        wire:click="closeModalshowThreeLastMovementFn"> Cerrar</button>
                </div>
            </div>
        </div>
    </div>


</div>
<?php /**PATH /home/alegas5/app.alegases.uy/resources/views/livewire/stock-list.blade.php ENDPATH**/ ?>