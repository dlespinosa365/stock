<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 font-weight-bold">
            <?php echo e(__('Inicio')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('movement-list-component')->html();
} elseif ($_instance->childHasBeenRendered('ryFL90V')) {
    $componentId = $_instance->getRenderedChildComponentId('ryFL90V');
    $componentTag = $_instance->getRenderedChildComponentTagName('ryFL90V');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ryFL90V');
} else {
    $response = \Livewire\Livewire::mount('movement-list-component');
    $html = $response->html();
    $_instance->logRenderedChild('ryFL90V', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
            <div class="col-md-12 mt-4">
                <div class="card">
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('stock-component')->html();
} elseif ($_instance->childHasBeenRendered('XaQKazF')) {
    $componentId = $_instance->getRenderedChildComponentId('XaQKazF');
    $componentTag = $_instance->getRenderedChildComponentTagName('XaQKazF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XaQKazF');
} else {
    $response = \Livewire\Livewire::mount('stock-component');
    $html = $response->html();
    $_instance->logRenderedChild('XaQKazF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-maintenance-list-component')->html();
} elseif ($_instance->childHasBeenRendered('nZj0Ixu')) {
    $componentId = $_instance->getRenderedChildComponentId('nZj0Ixu');
    $componentTag = $_instance->getRenderedChildComponentTagName('nZj0Ixu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nZj0Ixu');
} else {
    $response = \Livewire\Livewire::mount('product-maintenance-list-component');
    $html = $response->html();
    $_instance->logRenderedChild('nZj0Ixu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/alegas5/app.alegases.uy/resources/views/inicio.blade.php ENDPATH**/ ?>