<div class="py-3">
    <hr />
</div>
<?php /**PATH /home/denis/stock/alegas/resources/views/vendor/jetstream/components/section-border.blade.php ENDPATH**/ ?>