<div>
    <?php echo $__env->make('livewire.product-forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="col-md-12 text-end">
            <input type="search" wire:model="search" class="form-control float-end mx-2" placeholder="Buscar..."
                style="width: 230px" />
            <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                data-bs-target="#createProduct">Nuevo</button>
        </div>
        <?php if(session()->has('message')): ?>
            <br>
            <div class="col-md-12">
                <div class="alert alert-<?php echo e(session('type')); ?>" role="alert">
                    <?php echo session('message'); ?>

                </div>
            </div>
        <?php endif; ?>
        <div class="col-md-12">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Serie</th>
                        <th>Tipo</th>
                        <th>Proveedor</th>
                        <th>Ubicacion</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($product->id); ?></td>
                            <td><?php echo e($product->serial_number); ?></td>
                            <td><?php echo e($product->productType?->name); ?></td>
                            <td><?php echo e($product->provider?->name); ?></td>
                            <td><?php echo e($product->currentLocation?->name); ?></td>
                            <td>
                                <button type="button" data-bs-toggle="modal" data-bs-target="#updateProduct"
                                    class="btn btn-outline-primary"
                                    wire:click="edit(<?php echo e($product->id); ?>)">Editar</button>

                                <button type="button" data-bs-toggle="modal" data-bs-target="#prepareMoveToCustomer"
                                    class="btn btn-outline-primary"
                                    wire:click="prepareMoveToCustomer(<?php echo e($product->id); ?>)">Enviar a cliente</button>

                                <button type="button" data-bs-toggle="modal" data-bs-target="#markAsOutProduct"
                                    class="btn btn-outline-danger" wire:click="prepareMarkAsOut(<?php echo e($product->id); ?>)">Dar de
                                    baja</button>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">No se encontraron resultados</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <div>
                <?php echo e($products->links()); ?>

            </div>
        </div>

    </div>
</div>
<?php /**PATH /home/denis/stock/alegas/resources/views/livewire/product-list.blade.php ENDPATH**/ ?>