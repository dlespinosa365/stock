<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('images/alegas-36x36.png')); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
    <?php echo \Livewire\Livewire::styles(); ?>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>

    <!-- datepicker -->
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css"
        integrity="sha512-mSYUmp1HYZDFaVKK//63EcZq4iFWFjxSL+Z3T/aCt4IO9Cejm03q3NKKYN6pFQzY0SBOr8h+eCIAZHPXcpZaNw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/nprogress/0.2.0/nprogress.min.css"
        integrity="sha512-42kB9yDlYiCEfx2xVwq0q7hT4uf26FUgSIZBK8uiaEnTdShXjwr8Ip1V4xGJMg3mHkUt9nNuTDxunHF0/EgxLQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body class="font-sans antialiased bg-light">

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-menu')->html();
} elseif ($_instance->childHasBeenRendered('q5F6B5Y')) {
    $componentId = $_instance->getRenderedChildComponentId('q5F6B5Y');
    $componentTag = $_instance->getRenderedChildComponentTagName('q5F6B5Y');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('q5F6B5Y');
} else {
    $response = \Livewire\Livewire::mount('navigation-menu');
    $html = $response->html();
    $_instance->logRenderedChild('q5F6B5Y', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- Page Heading -->
    <header class="d-flex py-3 bg-white shadow-sm border-bottom">
        <div class="container">
            <h3><?php echo e($header); ?></h3>
        </div>
    </header>

    <!-- Page Content -->
    <main class="container my-5">
        <?php echo e($slot); ?>

    </main>

    <?php echo $__env->yieldPushContent('modals'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"
        integrity="sha512-T/tUfKSV1bihCnd+MxKD0Hm1uBBroVYBOYSk1knyvQ9VyZJpc/ALb4P0r6ubwVPSGB2GvjeoMAJJImBG12TiaQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/nprogress/0.2.0/nprogress.min.js"
        integrity="sha512-bUg5gaqBVaXIJNuebamJ6uex//mjxPk8kljQTdM1SwkNrQD7pjS+PerntUSD+QRWPNJ0tq54/x4zRV8bLrLhZg=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <!-- Custom script -->
    <script>
        window.addEventListener('close-modal', event => {
            $('#' + event.detail.id).modal('hide')
        })
        window.addEventListener('log', event => {
            console.log(event.detail.title, event.detail.message)
        })
        window.addEventListener('collapse-open', event => {
            const bsCollapse = new bootstrap.Collapse(event.detail.id, {
                show: true
            })
        })
        window.addEventListener('collapse-close', event => {
            const bsCollapse = new bootstrap.Collapse(event.detail.id, {
                hide: true
            })
        })
        window.addEventListener('collapse-toggle', event => {
            const bsCollapse = new bootstrap.Collapse(event.detail.id, {
                toggle: true
            })
            console.log('triggering collapse-toggle')
        })
        $('input[datepicker="true"]').datepicker({
            format: 'dd/mm/yyyy',
            language: 'es'
        })

        window.addEventListener('DOMContentLoaded', () => {
            this.livewire.hook('message.sent', () => {
                NProgress.start();
            })
            this.livewire.hook('message.processed', (message, component) => {
                NProgress.done();
            })
        });

    </script>
</body>

</html>
<?php /**PATH /home/denis/stock/alegas/resources/views/layouts/app.blade.php ENDPATH**/ ?>