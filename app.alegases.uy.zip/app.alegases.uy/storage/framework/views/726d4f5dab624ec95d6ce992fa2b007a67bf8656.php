<div>
    <div class="container">
        <div class="row mb-4">
            <div class="col-md-12 mb5">
                <h3 class="h3 my-4">Listado de productos por mantenimientos</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Serie</th>
                            <th>Ubicacion</th>
                            <th>Fecha de notificaion</th>
                            <th>Notificacion</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $productMaintenances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productMaintenance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($productMaintenance->product->serial_number); ?></td>
                                <td><?php echo e($productMaintenance->location->name); ?></td>
                                <td><?php echo e($productMaintenance->trigger_date->diffForHumans()); ?></td>
                                <td>
                                    <?php if($productMaintenance->is_sended): ?>
                                        <span class="badge text-bg-success">Si</span>
                                    <?php else: ?>
                                        <span class="badge text-bg-secondary">No</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5">No se encontraron resultados</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div>
                    <?php echo e($productMaintenances->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/denis/stock/alegas/resources/views/livewire/product-maintenance-list.blade.php ENDPATH**/ ?>