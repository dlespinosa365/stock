<div>
        <h6>Stock para ubicacion: <?php echo e($location->name); ?></h6>
        <table class="table table-sm" style="font-size: smaller">
            <thead>
                <tr>
                    <th scope="col">Producto</th>
                    <th scope="col">Numero de Serie</th>
                    <th scope="col">Ubicacion</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products_to_print; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($p->productType?->name); ?></td>
                        <td><?php echo e($p->serial_number); ?></td>
                        <td><?php echo e($p->currentLocation?->name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php /**PATH /home/alegas5/app.alegases.uy/resources/views/livewire/print-stock-by-location.blade.php ENDPATH**/ ?>