<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="h4 font-weight-bold">
            <?php echo e(__('Inicio')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('movement-list-component')->html();
} elseif ($_instance->childHasBeenRendered('TdzD8AQ')) {
    $componentId = $_instance->getRenderedChildComponentId('TdzD8AQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('TdzD8AQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TdzD8AQ');
} else {
    $response = \Livewire\Livewire::mount('movement-list-component');
    $html = $response->html();
    $_instance->logRenderedChild('TdzD8AQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
            <div class="col-md-12 mt-4">
                <div class="card">
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('stock-component')->html();
} elseif ($_instance->childHasBeenRendered('5Kn30xd')) {
    $componentId = $_instance->getRenderedChildComponentId('5Kn30xd');
    $componentTag = $_instance->getRenderedChildComponentTagName('5Kn30xd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5Kn30xd');
} else {
    $response = \Livewire\Livewire::mount('stock-component');
    $html = $response->html();
    $_instance->logRenderedChild('5Kn30xd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-maintenance-list-component')->html();
} elseif ($_instance->childHasBeenRendered('D6Z8Lnr')) {
    $componentId = $_instance->getRenderedChildComponentId('D6Z8Lnr');
    $componentTag = $_instance->getRenderedChildComponentTagName('D6Z8Lnr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('D6Z8Lnr');
} else {
    $response = \Livewire\Livewire::mount('product-maintenance-list-component');
    $html = $response->html();
    $_instance->logRenderedChild('D6Z8Lnr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /home/denis/stock/alegas/resources/views/inicio.blade.php ENDPATH**/ ?>