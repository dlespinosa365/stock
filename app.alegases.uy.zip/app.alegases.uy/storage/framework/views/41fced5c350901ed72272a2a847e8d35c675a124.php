<div>
    <?php echo $__env->make('livewire.movement-new-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container mb-2">
        <div class="row">
            <div class="col-md-12 mb5">
                <h3 class="h3 my-4">Movimientos</h3>
            </div>
            <div class="col-md-3">
                <input type="search" wire:model="serial_number" class="form-control" placeholder="Numero de serie"
                    style="width: 230px" />
            </div>
            <div class="col-md-3">
                <select class="form-select" aria-label="Tipo de movimiento" wire:model="movement_type_id">
                    <option selected>Tipo</option>
                    <?php $__currentLoopData = $MovementTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MovementType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($MovementType->id); ?>"><?php echo e($MovementType->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-6 text-end">
                <button type="button" class="btn btn-outline-primary" wire:click="toogleFilters">
                    <?php if($filters_is_open): ?>
                        Ver menos filtros
                    <?php else: ?>
                        Ver mas filtros
                    <?php endif; ?>
                </button>
                <button type="button" class="btn btn-outline-primary" wire:click="resetFiltersForm">
                    Resetear Filtros
                </button>
                <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                    data-bs-target="#createMovement" aria-expanded="true">
                    Nuevo Movimiento</button>
            </div>
        </div>

    </div>
    <?php if($filters_is_open): ?>
        <div class="container accordion-collapse pt-4 pb-4 shadow-sm rounded" id="moreFilters">
            <div class="row">
                <div class="col-md-3">
                    <label for="location_from_id" class="col-form-label">Origen</label>
                    <select class="form-select" aria-label="Desde la ubicacion" wire:model="location_from_id"
                        id="location_from_id" name="location_from_id">
                        <option selected>Desde la ubicacion</option>
                        <?php $__currentLoopData = $intern_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($location->id); ?>"><?php echo e($location->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($customer->location->id); ?>">[<?php echo e($customer->external_number); ?>] -
                                <?php echo e($customer->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="location_to_id" class="col-form-label">Destino</label>
                    <select class="form-select" aria-label="Hasta ubicacion" wire:model="location_to_id"
                        id="location_to_id" name="location_to_id">
                        <option selected>Hasta ubicacion</option>
                        <?php $__currentLoopData = $intern_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($location->id); ?>"><?php echo e($location->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($customer->location->id); ?>">[<?php echo e($customer->external_number); ?>] -
                                <?php echo e($customer->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="date" class="col-form-label">Desde</label>
                    <input type="date" wire:model="date_from" class="form-control" id="from" name="from">
                </div>
                <div class="col-md-3">
                    <label for="date"class="col-form-label">Hasta</label>
                    <input type="date" wire:model="date_to" class="form-control" id="to" name="to">
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="container mt-2">
        <?php if(session()->has('message')): ?>
            <br>
            <div class="col-md-12">
                <div class="alert alert-success" role="alert">
                    <?php echo session('message'); ?>

                </div>
            </div>
        <?php endif; ?>
        <?php if(session()->has('error_message')): ?>
            <br>
            <div class="col-md-12">
                <div class="alert alert-danger" role="alert">
                    <?php echo session('error_message'); ?>

                </div>
            </div>
        <?php endif; ?>
        <div class="col-md-12">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Tipo</th>
                        <th>Fecha</th>
                        <th>Desde</th>
                        <th>Hacia</th>
                        <th>Notas</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($movement->product->serial_number); ?></td>
                            <td><?php echo e($movement->movementType->name); ?></td>
                            <td><?php echo e($movement->created_at->toFormattedDateString()); ?></td>
                            <td><?php echo e($movement->locationFrom?->name); ?></td>
                            <td><?php echo e($movement->locationTo?->name); ?></td>
                            <td><?php echo e($movement->description); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">No se encontraron resultados</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <div>
                <?php echo e($movements->links()); ?>

            </div>
        </div>

    </div>
</div>
<?php /**PATH /home/alegas5/app.alegases.uy/resources/views/livewire/movement-list.blade.php ENDPATH**/ ?>