<?php return array (
  'custom-master-component' => 'App\\Http\\Livewire\\CustomMasterComponent',
  'customer-component' => 'App\\Http\\Livewire\\CustomerComponent',
  'location-component' => 'App\\Http\\Livewire\\LocationComponent',
  'movemen-type-component' => 'App\\Http\\Livewire\\MovemenTypeComponent',
  'movement-list-component' => 'App\\Http\\Livewire\\MovementListComponent',
  'print-stock-by-location-component' => 'App\\Http\\Livewire\\PrintStockByLocationComponent',
  'product-component' => 'App\\Http\\Livewire\\ProductComponent',
  'product-maintenance-list-component' => 'App\\Http\\Livewire\\ProductMaintenanceListComponent',
  'product-type-component' => 'App\\Http\\Livewire\\ProductTypeComponent',
  'provider-component' => 'App\\Http\\Livewire\\ProviderComponent',
  'stock-component' => 'App\\Http\\Livewire\\StockComponent',
);